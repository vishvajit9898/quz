jQuery(document).ready(function($) {
    //resetTimer()
    /*debugger;*/
    $('input[value="pausetimer_new_new"]').on('click', pausetimer_new_new);
    $('input[value="start_new"]').on('click', startTimer_new)
    $('input[value="stop_new"]').on('click', stopTimer_new)
    $('input[value="reset_new"]').on('click', resetTimer_new)
        // version two starts here 

    var startTime = convert_to_seconds();
    var currentTime = startTime;
    var myTimer
    var myTimerSpeed = 1000 // 1 sec




    function stopTimer_new() {
        clearInterval(myTimer);
        return false;
    }


    function resetTimer_new() {
        stopTimer_new();
        //  pauseTimer_new(); 
        var startTime = $("#current_section_time").val();
        console.log("bbbbbbbbbbbbbbbbbbbbbbb");
        console.log(startTime);
        console.log("bbbbbbbbbbbbbbbbbbbbbbb");
        currentTime = startTime;
        console.log("pppppppppppppppppppppppppppppppppppp");
        console.log(currentTime)
        console.log("pppppppppppppppppppppppppppppppppp")
            //section_timeisUp_new();
        currentTime = parseInt(currentTime);
        $('#timer').html(currentTime);
    }

    function startTimer_new() {
        $(".modal_back_button").css("display", "block");
        //alert("section timer new function called ");
        clearInterval(myTimer);
        if (currentTime <= 0) {
            resetTimer_new()
                //startTimer_new()
        } else {
            console.log("=======================================================");
            console.log(timerTick);
            console.log(myTimerSpeed);
            console.log("=======================================================");
            myTimer = setInterval(timerTick, myTimerSpeed);
        }
    }

    function stopTimer_new() {
        clearInterval(myTimer);
        //section_timeisUp_new(); // when time is up and movint to next
        /*alert("stopped function is called"); */
        /*$(".skip_section").click();   */
        /*alert("stopped function is called");*/
        $(".submit_exam").click();
        /*$(".modal_back_button").css("display", "none");*/
        return false;
    }



    function timerTick() {
        currentTime--
        $('#timer').html(time_format(currentTime))
        if (currentTime == 0) {
            stopTimer_new();
        }
    }

    // version two ends 


    function convert_to_seconds() {
        console.log("convert to seconds function called");
        /*alert("function called right now"); */
        $(".modal_back_button").css("display", "block");
        let current_id = $("#current_section").val(); //array id 
        console.log("(((((((((((((((((((((((((((((()))))))))))))))))))))))))))))))))))))))");

        console.log(section_array);
        console.log(section_array[current_id]);
        var section_time = section_array[current_id].section_time_section;
        console.log(section_time);

        var timesplit = section_time;
        var split_timer = timesplit.split(":");
        var hour_to_second = (parseInt(split_timer[0]) * 60) * 60;
        var hour_to_min = (parseInt(split_timer[1]) * 60);
        var hour_to_seconds = parseInt(split_timer[2]);
        $("#current_section_time").val(parseInt(hour_to_second + hour_to_min + hour_to_seconds));
        /*alert( parseInt(hour_to_second+hour_to_min+hour_to_seconds)); */
        console.log("(((((((((((((((((((((((((((((()))))))))))))))))))))))))))))))))))))))");
        //$("#reset_new").click();
        return parseInt(hour_to_second + hour_to_min + hour_to_seconds);

    }


    function time_format(time) {
        // Hours, minutes and seconds
        var hrs = ~~(time / 3600);

        var mins = ~~((time % 3600) / 60);
        var secs = ~~time % 60;

        // Output like "1:01" or "4:03:59" or "123:03:59"
        var ret = "";
        ret += "" + hrs + ":" + (mins < 10 ? "0" : "");
        ret += "" + mins + ":" + (secs < 10 ? "0" : "");
        ret += "" + secs;
        return ret;
    }


    function section_show_hide_2(show_section) {

        $(".section_buttons").removeClass('dn');
        $(".section_buttons").addClass('dn');
        $(".sectionCount_" + show_section).removeClass('dn');
        let current_section = $("#current_section").val();

        $(".questionlisting").addClass(" dns ");
        for (var i = section_array[0].question_start; i <= section_array[0].question_end; i++) {
            $(".questionListing_" + i).removeClass(" dns ");
        }

        $("#click_start_section_timer").click();
        $(".sectionCount_" + show_section).click();
    }



    function section_timeisUp_new() {

        console.log("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        console.log("Time is up");

        let total_sectionsllllllll = parseInt($("#total_sections_in_mocktest").val());
        console.log("Total sections in mock test " + total_sectionsllllllll);
        let section_array_count = (parseInt(total_sectionsllllllll) - 1);
        console.log("Total sections in mock test " + section_array_count);

        let current_section = $("#current_section").val();

        if (current_section == section_array_count) {
            //alert("Mock test ended here"); 
        } else {
            current_section = parseInt(current_section) + 1;
            section_show_hide_2(current_section);
            $("#current_section").val(parseInt(current_section));
            show_hide_right_questions_number();
            $("#start_new").click();
            $(".start_stop_main_timer").click();
            convert_to_seconds();
            //alert("button clicked");
        }

        console.log("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");

    } // end of function


    $(".skip_section").click(function() {
        $("#reset_new").click();
        section_timeisUp_new();
        resetTimer_new();
        startTimer_new();
        startTimer();

    });


    $(".popupclosed").click(function() {
        $(".modal_back_button").click();
        $(".closethisthis").click();
        $("#submit_mocktest").click();
    });


    function pausetimer_new_new() {
        clearInterval(myTimer);
        return false;
    }


    let timerx, sec;

    $("#start_march").click(function() {
        // Toggle between start/stop
        sec ? stopTimer() : startTimer();
    });

    $("#pause").click(function() {
        // Toggle between pause/resume
        timerx ? pauseTimer() : resumeTimer();
    });

    function startTimer() {

        var get_total_section = parseInt($("#total_sections_in_mocktest").val()) - 1;
        var current_section = parseInt($("#current_section").val());
        var section_time = section_array[3].section_time_section;

        //var sec = parseInt($("#current_section_time").val()); // the value will change over here /deepesh today 28 march
        console.log("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        // console.log(sec);
        // console.log(get_total_section);
        // console.log(current_section);
        // console.log(section_time);

        console.log("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        if (get_total_section == current_section) {
            stopTimer();
            //sec = parseInt($("#timer_this").val());
            sec = parseInt($("#current_section_time").val());
            //var sec = parseInt($("#current_section_time").val()); // the value will change over here /deepesh today 28 march
            resumeTimer();
            $("#start_march").text("stop");
            $("#pause").prop("disabled", false);
        }

    }

    function resumeTimer() {
        // Start timer
        // alert("function called resume timer");
        // alert(sec);

        timerx = setInterval(() => {
            // Update time remaining
            $("#timer_check_new").text(--sec);

            if (sec === 0) {
                // Handle timeout
                stopTimer();
                $("#submit_test").click();

            }
        }, 1000);
        $("#timer_check_new").text(sec);
        $("#pause").text("pause");
    }

    function stopTimer() {
        // Start timer and clear remainng time
        sec = 0;
        pauseTimer();
        $("#timer_check_new").text("");
        $("#start_march").text("start");
        $("#pause").prop("disabled", true);
    }

    function pauseTimer() {
        // Just stop the timer
        timerx = clearInterval(timerx);
        $("#pause").text("resume");
    }



}); // end of document .ready