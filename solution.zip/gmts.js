

function first_step() {

    $(".next_1").click(function () {
        $(".instructions_1").hide();
        $(".instructions_2").show();
        $(".footer_button_1").hide();
        $(".footer_button_2").show();
        $("#checkbeforeexam").parent("p").addClass('check_box_for_mocktest');
        $(".right_side_hide_show").css("display", "flex");
    });
}
first_step();
setHeighttoofmainDiv();

function pre_b_exam() {
    $(".instructions_1").show();
    $(".instructions_2").hide();
    $(".footer_button_1").show();
    $(".footer_button_2").hide();
}

function setHeighttoofmainDiv() {

    if (window.matchMedia("(max-width: 767px)").matches) {
        $(".show_hide_on_mobile").addClass('collapse_new');
        $(".show_hide_on_mobile").addClass('');
        //$(".mobile_wrapper").height("300px"); 
        $(".mobile_wrapper").css('background', '#a5c3d2');
        $(".mobile_submit_button").fadeIn();
        $(".hide_in_mobile").fadeOut();
        $(".show_in_mobile").fadeIn();
        $(".mark-review").html("Mark & Next");
        $(".clear-response").html("Clear");

    } else {
        var body_height = parseFloat($("html").outerHeight());
        var header_height = parseFloat($(".fixed-headerfor_height").outerHeight());
        var footer_height = parseFloat($(".footer").outerHeight());
        var section_div = parseFloat($(".section_div").outerHeight());
        var main_div_height = parseFloat(body_height - (header_height + footer_height));
        var height_of_questions = parseFloat(body_height - (header_height + section_div + section_div));

        $(".dynamic_height").css("height", parseInt(main_div_height - 20));
        $(".right_fix_div").addClass('dn');
        $(".show-fix-first").addClass('dn');
        $(".test").css("display", "none");
        $(".mobile_submit_button").fadeOut();
        //$(".hide_in_mobile").fadeIn();
        $(".mark-review").html("Mark for Review & Next ");
        $(".clear-response").html("Clear Response");
        $(".fix-height").css("height", height_of_questions);
        $(".height_of_questio_option_div").css('height', (height_of_questions - (100 + footer_height + section_div + header_height)));

    }

}


function onlyonmobile() {
    if (window.matchMedia("(max-width: 767px)").matches) {
        $(".show_hide_on_mobile").addClass('dn');
    }
    /*else{
            $(".hide_in_mobile").addClass('dn');
        }*/
}

onlyonmobile();


function start_gmt_button() {
    window.localStorage.removeItem('myObject');
    if ($("#drop option:selected").val() == "") {
        alert("Please Select default Language.");
        return false;
    } else {
        if ($("#checkbeforeexam").prop("checked") == false) {
            alert("Please accept terms and Condition before proceeding.");
            return false;
        } else {
            $(".footer_button_2").css('display', 'none'); // hiding the second button
            $(".footer_button_3").fadeIn(); //showing the div to start exam
            var language_selected = $("#drop option:selected").val();
            $("#language").val($.trim(language_selected)); //user will give test in english or hindi.
            var thislanguage = $("#drop option:selected").val();
            $("#find_if_dual_language").val(thislanguage);
            $("#start").click();
            start_the_gmt();
            $(".questions_main").fadeIn();
            $(".instructions_1").hide();
            $(".instructions_2").hide();
            $(".show_when_exam_start").css('display', 'block');
            var question_number = 0;
            firstquestion_display(questionList, language_selected, question_number);
            var get_selected_section_id = $.trim($("#default_section").val());

            if (section_wise_or_not == 1) {
                $(".remove_dn_" + get_selected_section_id).removeClass('dn');
                var section_first_section_id = $("#default_section").val();
                $("#section_time").val($("#subjects_" + section_first_section_id).attr('data-section-time'));
            } else {
                $(".questionlisting").removeClass('dn');
            }
            $(".start_timer_stop_timer").click(); // timer will start here
            $(".start_stop_main_timer").click();
            single_question_timer(); //single question wala timer wala
            $(".questionListing_0").click();
            $("#pause_mock_test").css('display', 'block');
            $(".show-fix-first").removeClass('dn');

            if (window.matchMedia("(max-width: 767px)").matches) {
                $(".show_hide_on_mobile").addClass('dn');
                $(".hide_in_mobile").fadeOut();
            } else {
                $(".hide_in_mobile").fadeIn();
                //$(".hide_in_mobile").addClass('dn');
            }

            var get_the_language = $("#find_if_dual_language").val();
            $('#change_laguage').val(get_the_language).change();

        } // if every thing goes well. 


    }
} // end of the function 




function start_the_gmt() {
    let mocktestid = $.trim($("#mocktest_enc_id").val());
    let selected_language_type = $.trim($("#language").val());

    data = { 'selected_language_type': selected_language_type, 'mocktestid': mocktestid }

    //console.log(data);
    $("#mocktest_primary_key").val(data);

}


function start_stop_timer(start_stop, timer) {
    var interval = 1000,
        value = 0;

    if (start_stop == 'start' && timer >= 0) {

        if (timer !== null) return;
        timer = setInterval(function () {
            value = (value + 1);
            $("#input").val(value);
        }, interval);
        console.log(timer);
    }

}

function check_internet_connection() {
    if (!navigator.onLine) {
        $('#nointernetconnection').modal('show');
        return false;
    }

}



$(function () {
    var timer = null,
        interval = 1000,
        value = 0;

    $("#start").click(function () {
        if (timer !== null) return;
        timer = setInterval(function () {
            $("#input").val(++value);
        }, interval);
    });

    $("#stop").click(function () {
        clearInterval(timer);
        timer = null
    });
});

function firstquestion_display(questionList, language_selected, question_number) {

    $("#currentQuestion").val(questionList[question_number].question_number);
    $("#currentQuestionId").val(questionList[question_number].questionId);
    $("#current_subject").val(questionList[question_number].new_subject);
    $("#current_chapter").val(questionList[question_number].new_chapter);

    if (language_selected == "english") {
        var question_name = questionList[question_number].main_question;
        var options = questionList[question_number].options;
        if (questionList[question_number].group_question == "") {
            var question_direction = (questionList[question_number].question_direction == "") ? "" : "<strong>    Direction</strong>" + questionList[question_number].question_direction;
        } else {
            var question_direction = (questionList[question_number].group_question == "") ? "" : "<strong>Direction</strong>" + questionList[question_number].group_question;
        }
        var maderchod_options = questionList[question_number].options;
        var current_question_number = questionList[question_number].question_number;
        var new_subject = questionList[question_number].new_subject;
    } else {
        var question_name = questionList[question_number].main_question_hindi;
        var options = questionList[question_number].options_hindi;
        var maderchod_options = questionList[question_number].options_hindi;
        var current_question_number = questionList[question_number].question_number;
        var new_subject = questionList[question_number].new_subject;
        if (questionList[question_number].group_question == "") {
            var question_direction = (questionList[question_number].question_direction_hindi == "") ? "" : "<strong>Direction</strong>" + questionList[question_number].question_direction_hindi;
        } else {
            var question_direction = (questionList[question_number].group_question_hindi == "") ? "" : "<strong>Direction</strong>" + questionList[question_number].group_question_hindi;
        }
    }

    // var check_for_dual_languge = $("#find_if_dual_language").val(); 
    // if(check_for_dual_languge == "both_language"){
    //     $(".question_div").html(question_direction + '<br/>' + question_name);
    //     $(".question_with_directions").html(); 
    // }else{
    //     $(".question_with_directions").html(); 
    //     $(".question_div").html(question_direction + '<br/>' + question_name);
    // }
    if (question_direction == "") {
        $(".question_div").css("display", "none");
        // $(".question_div").html(question_direction);
        $(".height_of_questio_option_div").removeClass("col-sm-12 col-md-5 col-lg-6 col-xl-4").addClass("col-sm-12 col-md-12 col-lg-12 col-xl-12 ");
        $(".question_with_directions").html("<strong>Question:</strong>" + question_name);
    } else {
        $(".height_of_questio_option_div").removeClass("col-sm-12 col-md-12 col-lg-12 col-xl-12").addClass("col-sm-12 col-md-5 col-lg-6 col-xl-4");
        console.log("there is the scope of group direction");
        $(".question_div").css("display", "block");
        $(".question_div").html(question_direction);
        $(".question_with_directions").html("<strong>Question:</strong>" + question_name);
    }




    $(".options_url").html(maderchod_options);
    $("#question_number").html(parseInt(current_question_number) + 1);
    $("#current_question_number").html(current_question_number);

    $(".marks").html("+ " + questionList[question_number].marks);
    $(".marks-negative").html(questionList[question_number].negative_marks);

    $(".box-ul li").removeClass('box-selected');
    $(".questionListing_" + question_number).addClass('box-selected');
    // removing the color from the sections and then applying it back
    $(".section_buttons").removeClass('section_button_selected');
    $("#subjects_" + new_subject).addClass('section_button_selected');

}

function ajax_call() {
    var mocktest = '2596a54cdbb555cfd09cd5d991da0f55';

    data = { 'answerSelectedArray2': answerSelectedArray2, 'selected_language_type2': selected_language_type2 }

    $(".btn_change").css('display', 'block');
    $(".loading-button").css('display', 'none');


}


function setcheckedvalue(currentId, option_selected) {

    $.each(questionList, function (key, values) {
        if (values.questionId == currentId) {
            questionList[key].answer_given = option_selected;
        }

    });

}

function selectradioongoingback(questionId) {
    var option_selected = "";
    $.each(questionList, function (key, values) {
        if (values.questionId == questionId) {
            option_selected = values.answer_given;
        }
    });
    $("input[name='question_" + questionId + "'][value='" + option_selected + "']").attr('checked', true);
    console.log("function was called");
}

function change_color_on_numbers(question_number, color) {

    let array_count = parseInt(question_number) - 1;

    $(".questionListing_" + array_count).removeClass('greencolor');
    $(".questionListing_" + array_count).removeClass('purple');
    $(".questionListing_" + array_count).removeClass('red');
    $(".questionListing_" + array_count).removeClass('purple_checked');



    $(".questionListing_" + array_count).addClass(color);
    questionList[array_count].color_class = color;
}


function single_question_timer() {
    var timeinterval = setInterval(function () {
        gettime = parseInt($("#single_time").html());
        gettime = gettime + 1;
        $("#single_time").html(gettime);
    }, 1000);
    return timeinterval
}

function showStatus(status) {
    if (status == 'false') {

        //internet not working properly
        // $(".demo_button_for_internet").click();
        /*$("#pause_mock_test").click(); */

        $("#pauseBtnhms").click();

        $("#no-internet").click();
    }
}

function checkinternetconnection() {

    // 1st, we set the correct status when the page loads
    navigator.onLine ? showStatus(true) : showStatus(false);
    // now we listen for network status changes
    window.addEventListener('online', () => {
        showStatus(true);
    });

    window.addEventListener('offline', () => {
        showStatus(false);
        $("#pauseBtnhms").click();

        $("#no-internet").click();

    });

}

function escapeHtml(text) {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function (m) { return map[m]; });
}


function ajaxcall() {
    let language = $("#language").val();
    var this_question_number = parseInt($("#previous_question_number").val());
    let mocktest_enc_id = $.trim($("#mocktest_enc_id").val());
    let mocktest_id = $.trim($("#mocktest_id").val());
    let question_id = questionList[this_question_number].questionId;
    let answer_given = questionList[this_question_number].answer_given;
    let chapter_id = questionList[this_question_number].new_chapter;
    let subject_id = questionList[this_question_number].new_subject;
    let time_taken = parseInt($("#single_time").html());
    let color = questionList[this_question_number].color_class;
    let mocktest_primary_key = $("#mocktest_primary_key").val();
    console.log(mocktest_primary_key);

    data = { 'language': language, 'mocktest_enc_id': mocktest_enc_id, 'mocktest_id': mocktest_id, 'question_id': question_id, 'answer_given': answer_given, 'subject_id': subject_id, 'chapter_id': chapter_id, 'time_taken': time_taken, 'color': color, 'mocktest_primary_key': mocktest_primary_key }

    console.log("==========================");
    console.log(data);
    console.log("==========================");


    var crt_qus = $('#current_question_number').text();
    var ttl_qus = $('#total_question').val();

    if (ttl_qus - crt_qus == 1 && answer_given != "-1") {
        // $('.submit_exam').click();
        // console.log(answer_given);
        // console.log( ttl_qus)
        // console.log( crt_qus)
    }
}

// function getCookie(cname) {
//     let name = cname + "=";
//     let decodedCookie = decodeURIComponent(document.cookie);
//     let ca = decodedCookie.split(';');
//     for (let i = 0; i < ca.length; i++) {
//         let c = ca[i];
//         while (c.charAt(0) == ' ') {
//             c = c.substring(1);
//         }
//         if (c.indexOf(name) == 0) {
//             return c.substring(name.length, c.length);
//         }
//     }
//     return "";
// }

function submit_mocktest() {

    let language = $("#language").val();
    let mocktest_enc_id = $.trim($("#mocktest_enc_id").val());
    let mocktest_id = $.trim($("#mocktest_id").val());
    let back_to_course = $.trim($("#back_to_course").val());
    // var cookie_data    = $('#cookie_check').val();
    // var c              = getCookie('without_login_mocktest_primary_key');


    $(".close").click();

    data = { 'language': language, 'mocktest_enc_id': mocktest_enc_id, 'mocktest_id': mocktest_id }


    $(".overlay").css('display', 'block');
    $(".overlay").css('display', 'block');
    $(".loading-div").css('display', 'block');
    var descriptive_id = $("#descriptive_mocktest").val();
    var redirect_another_id = $("#redirect_another_id").val();

    var b = [
        {
            "answer": 2
        },
        {
            "answer": 2
        },
        {
            "answer": 2
        },
        {
            "answer": 2
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 0
        },
        {
            "answer": 2
        },
        {
            "answer": 2
        }
    ]

    var right = 0;
    var wrong = 0;
    var notans = 0;
    var markk2 = 0;
    var pls=0;
    var mins=0;
    var wrongnum=[];
    var rightnum=[];
    for (i = 0; i < questionList.length; i++) {
        console.log(questionList[i].answer_given)

        if (questionList[i].answer_given == b[i].answer) {
            right++;
            rightnum[i]=questionList[i].question_number;
        } else if (questionList[i].answer_given != b[i].answer && questionList[i].answer_given != -1) {
            wrong++;
            wrongnum[i]=questionList[i].question_number;
        }

        if (questionList[i].answer_given == b[i].answer && questionList[i].marks == 2) {
            pls += 2;
        }
        
        if (questionList[i].answer_given == b[i].answer && questionList[i].marks == 1) {
            pls += 1;
        }
       
        if (questionList[i].answer_given != b[i].answer && questionList[i].answer_given != -1 && questionList[i].marks == 2) {
            mins+=-0.50;
        }
        if (questionList[i].answer_given != b[i].answer && questionList[i].answer_given != -1 && questionList[i].marks == 1) {
            mins+=-0.25;
        }
    }
    // console.log(right)
    // console.log(30 - right)
    // console.log(wrong)
    console.log(pls)
    console.log(mins)

    markk2=pls+mins;
    console.log(markk2)

    console.log(questionList)
    window.localStorage.setItem("myObject", JSON.stringify(questionList));
    window.localStorage.setItem("rig", JSON.stringify(rightnum));
    window.localStorage.setItem("ron", JSON.stringify(wrongnum));
    let newObject = window.localStorage.getItem("myObject");
console.log(JSON.parse(newObject));
    var x = "<tr>" +
        "<td><strong>Sections</strong></td>" +
        "<td><strong>No of Question</strong></td>" +
        "<td><strong>Answered</strong></td>" +
        "<td><strong>Not Answered</strong></td>" +
        "<td><strong>Marked for Review</strong></td>" +
        "<td><strong>Not Visited</strong></td>" +
        "<td><strong>Right Answer</strong></td>" +
        "<td><strong>Wrong Answer</strong></td>" +
        "<td><strong>Your Score</strong></td>" +
        "</tr>";
    $("#table_final").append(x);
    $.each(subject_array_question_wise, function (key, values) {
        // console.log(values);
        // var res = right - get_section_data(questionList, values, 'not_answered') - (wrong * 1.25);
        var x = "<tr>" +
            "<td><strong>" + values + "</strong></td>" +
            "<td>" + get_section_data(questionList, values, 'no_of_questions') + "</td>" +
            "<td>" + get_section_data(questionList, values, 'no_of_question_answered') + "</td>" +
            "<td>" + get_section_data(questionList, values, 'not_answered') + "</td>" +
            "<td>" + get_section_data(questionList, values, 'answered_marked') + "</td>" +
            "<td>" + get_section_data(questionList, values, 'not_visited') + "</td>" +
            "<td>" + right + "</td>" +
            "<td>" + wrong + "</td>" +
            "<td><h3>" + markk2 + "/50</h3></td>" +
            "</tr>";
        console.log(x);
        $("#table_final").append(x);
    });

    $("#finalModal").css('display', 'block');
}

function all_work_here(color) {

    $("#previous_question_number").val($("#current_question_number").val());
    var total_question = $("#total_question").val();
    var question_number = (parseInt($("#current_question_number").val()) + 1);
    var language_selected = $("#drop option:selected").val();

    if ((total_question - 1) == $("#current_question_number").val()) {
        ajaxcall();
        if (color != "") {
            change_color_on_numbers(question_number, color);
            $("#single_time").html(parseInt(0));
        }
    } else {
        $("#current_question_number").val(question_number);
        firstquestion_display(questionList, language_selected, question_number);
        $(".questionListing_" + question_number).attr('data-questionid');
        selectradioongoingback($(".questionListing_" + question_number).attr('data-questionid'));
        ajaxcall();
        if (color != "") {
            change_color_on_numbers(question_number, color);
            $("#single_time").html(parseInt(0));
        }

    }
}

function img_width_set() {
    var img_width = $(".question_div img").width();
    if (img_width > 400) {
        //$(".question_div img").css('width', '500px'); 
        $(".question_div img").css('width', '100%');
    } else {
        $(".question_div img");
    }
}

function get_section_data(question_array, section_name, type) {
    // get_section_data
    var section_question_count = 0;
    var section_answer_count = 0;
    var total_question_answered = 0;


    $.each(question_array, function (key, values) {
        if (type == "no_of_questions" && questionList[key].subject_name == section_name) {
            section_question_count = (section_question_count + 1);
        }

        if (type == "no_of_question_answered" && questionList[key].subject_name == section_name && questionList[key].answer_given != -1 && questionList[key].color_class == 'green') {
            section_question_count = (section_question_count + 1);
        }

        if (type == "not_answered" && questionList[key].subject_name == section_name && questionList[key].answer_given == -1 && questionList[key].color_class == 'red') {
            section_question_count = (section_question_count + 1);
        }

        if (type == "answered_marked" && questionList[key].subject_name == section_name && (questionList[key].color_class == 'purple_checked' || questionList[key].color_class == 'purple')) {
            section_question_count = (section_question_count + 1);
        }

        if (type == "not_visited" && questionList[key].subject_name == section_name && (questionList[key].color_class == null || questionList[key].color_class == 'null') && questionList[key].answer_given == -1) {
            section_question_count = (section_question_count + 1);
        }

        /* if(type == "not_answered" && questionList[key].subject_name == section_name && questionList[key].answer_given != -1){
           section_question_count = (section_question_count+1); 
         }*/

    });

    return section_question_count;
    // no_of_answers
}

jQuery(document).ready(function ($) {

    // let current_question_number = $.trim(parseInt($("#current_question_number").val()));
    // let answer_given_status = $.trim(parseInt(questionList[current_question_number].answer_given));

    $("#change_laguage").click(function () {
        var select_language = $(this).find(":selected").val();
        $("#previous_question_number").val($("#current_question_number").val());
        var total_question = $("#total_question").val();
        var question_number = (parseInt($("#current_question_number").val()));
        var language_selected = $("#drop option:selected").val();

        if (select_language == "english") { // is for english
            firstquestion_display(questionList, "english", question_number);
            selectradioongoingback($(".questionListing_" + question_number).attr('data-questionid'));
        } else if (select_language == "hindi") { // is for hindi
            firstquestion_display(questionList, 'hindi', question_number);
            selectradioongoingback($(".questionListing_" + question_number).attr('data-questionid'));
        } else {
            var default_language = $("#find_if_dual_language").val();
            firstquestion_display(questionList, 'default_language', question_number);
            selectradioongoingback($(".questionListing_" + question_number).attr('data-questionid'));
        }
    });



    $(".save-next").click(function () {
        checkinternetconnection();
        var get_the_language = $("#find_if_dual_language").val();
        $('#change_laguage').val(get_the_language).change();

        let current_question_number = $.trim(parseInt($("#current_question_number").val()));
        let answer_given_status = $.trim(parseInt(questionList[current_question_number].answer_given));

        if (parseInt(answer_given_status) == -1 || parseInt(answer_given_status == '')) {
            var color = "red";
        } else {
            var color = "green";
        }


        questionList[current_question_number].color_class = color;
        all_work_here(color);
        img_width_set();



    });

    $(".questionlisting").click(function () {
        checkinternetconnection();

        var get_the_language = $("#find_if_dual_language").val();
        $('#change_laguage').val(get_the_language).change();

        $("#previous_question_number").val(parseInt($("#current_question_number").val()));
        var current_question = $(this).attr('data-value');
        $("#current_question_number").val(parseInt(current_question));
        var total_question = $("#total_question").val();
        var language_selected = $("#drop option:selected").val();
        var question_number = (parseInt($("#current_question_number").val()));
        if ((total_question) == $("#current_question_number").val()) {
            ajaxcall();
        } else {

            firstquestion_display(questionList, language_selected, question_number);
            $(".questionListing_" + question_number).attr('data-questionid');
            selectradioongoingback($(".questionListing_" + question_number).attr('data-questionid'));
            var color = questionList[parseInt($("#previous_question_number").val())].color_class;
            var old_question_number = parseInt($("#previous_question_number").val()) + 1;

            if (color == null || color == "" || color == "null" || color === null) {
                let color_new = "red";
                change_color_on_numbers(old_question_number, color_new);
                $("#single_time").html(parseInt(0));
            } else {
                let color_new = color;
                change_color_on_numbers(old_question_number, color_new);
                $("#single_time").html(parseInt(0));
            }
            ajaxcall();
        }
        img_width_set();

        // var img = $(".question_div").find("img").map(function () {
        //     var x = get_hostname($(this).attr('src'));
        //     console.log(x);
        //     var x = get_hostname($(this).attr('src'));
        //     if(x == 'http://www.imathas.com'){
        //         $(this).css('width', 'auto');
        //     }
        //     }).get();
        var img = $(".container-fluid").find("img").map(function () {
            var x = get_hostname($(this).attr('src'));
            if (x == 'http://www.imathas.com') {
                $(this).css('width', 'auto');
            }
        }).get();

    });



    $(".mark-review").click(function () {
        checkinternetconnection();
        current_question_number = parseInt($("#current_question_number").val());
        var answer_given_status = parseInt(questionList[current_question_number].answer_given);
        if (answer_given_status >= 0) {
            var color = "purple_checked";
        } else {
            var color = "purple";
        }
        questionList[current_question_number].color_class = color;
        all_work_here(color);
        img_width_set();

    });


    $(".clear-response").click(function () {
        checkinternetconnection();
        var current_question_id = parseInt($("#current_question_number").val());
        var real_question_id = parseInt(questionList[$("#current_question_number").val()].questionId);
        $(".questiontosavee_" + real_question_id).attr("checked", "false");
        $("input[name='question_" + real_question_id + "']").attr('checked', false);
        var question_id = real_question_id;
        var mocktestid = $.trim($("#mocktest_enc_id").val());


        data = { 'mocktestid': mocktestid, 'question_id': question_id },

            $(".questionListing_" + current_question_id).removeClass('green');
        $(".questionListing_" + current_question_id).removeClass('purple_checked');
        $(".questionListing_" + current_question_id).removeClass('purple');
        $(".questionListing_" + current_question_id).addClass('red');


        questionList[current_question_id].answer_given = -1;
        questionList[current_question_id].color_class = "red";
    });


    $(".section_buttons").click(function () {
        var section_tab_clicked = $(this).attr("data-first_question");
        section_tab_clicked = section_tab_clicked;
        $(".questionListing_" + section_tab_clicked).click();
    });



    $("#start_stop_main_timer").click(function () {
        var timesplit = $("#mocktest_total_time").val().split(':');
        var time_hours = timesplit[0];
        var time_min = timesplit[1];
        var time_second = timesplit[2];
        $('#hms_timer_duplicate').countdowntimer({
            hours: time_hours,
            minutes: time_min,
            seconds: time_second,
            size: "lg",
            pauseButton: "pauseBtnhms",
            stopButton: "stopBtnhms",
            timeUp: timeisUp
        });
    });

    function timeisUp() {
        $("#submit_test").click();
    }

    $(".submit_exam").click(function () {

        var final_array = questionList;
        $("#table_for_submit").html("");
        var x = "<tr>" +
            "<td><strong>Sections</strong></td>" +
            "<td><strong>No of Question</strong></td>" +
            "<td><strong>Answered</strong></td>" +
            "<td><strong>Not Answered</strong></td>" +
            "<td><strong>Marked for Review</strong></td>" +
            "<td><strong>Not Visited</strong></td>" +
            "</tr>";
        $("#table_for_submit").append(x);
        $.each(subject_array_question_wise, function (key, values) {
            // console.log(values);
            var x = "<tr>" +
                "<td><strong>" + values + "</strong></td>" +
                "<td>" + get_section_data(questionList, values, 'no_of_questions') + "</strong></td>" +
                "<td>" + get_section_data(questionList, values, 'no_of_question_answered') + "</strong></td>" +
                "<td>" + get_section_data(questionList, values, 'not_answered') + "</strong></td>" +
                "<td>" + get_section_data(questionList, values, 'answered_marked') + "</strong></td>" +
                "<td>" + get_section_data(questionList, values, 'not_visited') + "</strong></td>" +
                "</tr>";
            console.log(x);
            $("#table_for_submit").append(x);
        });
        $("#submit_mocktest").click();

    });

    $(".report-issue").click(function () {
        $("#report_an_issue_id").click();
        $("#report_question_issue").html("");
        var current_question = parseInt($('#current_question_number').val());
        var question = questionList[current_question].main_question;
        $("#report_question_issue").html(question);

    });

    $(".error_submit").click(function () {

        var questionId = $(".questionListing_" + $("#current_question_number").val()).attr('data-questionid'); // parseInt($.trim($("#current_question_number").val()));
        let mocktest_enc_id = $.trim($("#mocktest_enc_id").val());
        var error_description = $.trim($("#report_issue").val());
        var issue = $.trim($("#id_issuereprt").val());

        if (error_description == "") {
            $("#report_issue").css('border', '1px solid red');
            alert("Please enter the issue or bug");
            return false;
        }


        data = { 'question_id': questionId, 'mocktest_id': mocktest_enc_id, 'error_description': error_description, issue: issue }

        //console.log(data);
        $('#report_issue_triger').modal('hide');
        $(".pause_dialog_close_error").click();



    });


    $("#pause_mock_test").click(function () {
        $("#pauseBtnhms").click();
        $("#pause_mocktest_button").click();
        var time_spend_on_question = parseInt($("#single_time").html());
        $("#save_single_question_timer_on_pause").html(parseInt(time_spend_on_question));
        let mocktest_enc_id = $.trim($("#mocktest_enc_id").val());
        let current_question = $.trim($("#current_question_number").val());

        data = { 'mocktest_enc_id': mocktest_enc_id, 'current_question': current_question }

        /*$(".pause_dialog_close_error").click();*/
        console.log('Pause');
        // console.log(data); 

    });

    $("#pause_mocktest").modal({
        show: false,
        backdrop: 'static'
    });

    $("#no_internet_modal").modal({
        show: false,
        backdrop: 'static'
    });

    $("#resume_mock_test").click(function () {
        $("#pauseBtnhms").click();
        $(".close").click();
        $(".pause_dialog_close").click();
        var time_on_this_question = parseInt($("#save_single_question_timer_on_pause").html());
        $("#single_time").html(time_on_this_question);
        let mocktest_enc_id = $.trim($("#mocktest_enc_id").val());
        let current_question = $.trim($("#current_question_number").val());

        data = { 'mocktest_enc_id': mocktest_enc_id, 'current_question': current_question }

        /*$(".pause_dialog_close_error").click();*/
        console.log('resomed mocktest');
        // console.log(data); 




    });


    $(".right_fix_div").click(function () {
        $(".collapse_new").addClass('collapse_show');
        $(".show-fix-first").addClass('dn');
        $(".hide-fix-first").removeClass('dn');
        $('.overlay_mobile').css("display", "block");
        $("collapse_new").removeClass('dn');
        $(".collapse_new").removeClass('dn');

    });


    $(".hide-fix-first").click(function () {
        $(".collapse_new").removeClass('collapse_show');
        $(".show-fix-first").removeClass('dn');
        $(".hide-fix-first").addClass('dn');
        $('.overlay_mobile').css("display", "none");
        $("collapse_new").addClass('dn');

    });


}); // end of document .ready

function get_hostname(url) {
    var m = url.match(/^http:\/\/[^/]+/);
    return m ? m[0] : null;
}